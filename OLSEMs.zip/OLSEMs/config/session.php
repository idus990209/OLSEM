<?php

session_start();
$name = $_SESSION['email'] ?? 'Guest';
?>