<?php 
include("db/dbQuery.php");
$config = include('db/config.php');
include("function.php");
?>