<?php

/* local environment */
return array(
    "dbHost" => "localhost",
    "dbName" => "olsem",
    "dbUserName" => "root",
    "dbPassword" => "",
    "email" => "",
    
);
